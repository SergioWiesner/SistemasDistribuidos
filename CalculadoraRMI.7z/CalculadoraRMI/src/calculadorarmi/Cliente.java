/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadorarmi;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author webdev
 */
public class Cliente {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            Registry miRegistro = LocateRegistry.getRegistry("localhost", 1099);
            Calculadora c = (Calculadora) Naming.lookup("//localhost/calculadora");
            while (true) {
                String menu = JOptionPane.showInputDialog("Calculadora de sergio \n Calculadora en RMI. \n\n 1. Suma \n 2. Resta \n 3. Multiplicación \n 4. División");
                switch (menu) {
                    case "1": {
                        int a = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                        int b = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                        JOptionPane.showMessageDialog(null, "La suma es : " + c.sum(a, b));
                        break;
                    }
                    case "2": {
                        int a = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                        int b = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                        JOptionPane.showMessageDialog(null, "La suma es : " + c.rest(a, b));
                        break;
                    }
                    case "3": {
                        int a = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                        int b = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                        JOptionPane.showMessageDialog(null, "La suma es : " + c.mult(a, b));
                        break;
                    }
                    case "4": {
                        int a = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                        int b = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                        JOptionPane.showMessageDialog(null, "La suma es : " + c.div(a, b));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Servidor no conectado");
        }
    }
}
