/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadorarmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author webdev
 */
public class Rmi extends UnicastRemoteObject implements Calculadora {

    public Rmi() throws RemoteException {
        int a, b;
    }

    @Override
    public int div(int a, int b) throws RemoteException {
        return a / b;
    }

    /**
     *
     * @param a
     * @param b
     * @return
     * @throws RemoteException
     */
    @Override
    public int mult(int a, int b) throws RemoteException {
        return a * b;
    }

    /**
     *
     * @param a
     * @param b
     * @return
     * @throws RemoteException
     */
    @Override
    public int sum(int a, int b) throws RemoteException {
        return a + b;
    }

    @Override
    public int rest(int a, int b) throws RemoteException {
        return a - b;
    }

}
